
  # Sales Report Prototype

  This is a code bundle for Sales Report Prototype. The original project is available at https://www.figma.com/design/adEb8VEvLm3g4rOxtRBvHK/Sales-Report-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  